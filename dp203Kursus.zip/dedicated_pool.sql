-- Dag 3 

-- External tables 
--	findes p� serverless pool


-- to veje til at f� data ind i synapse dedicated pool (begge peger ud til blob)
-- 1) Polybase teknik (External table)
-- 2) COPY INTO

CREATE SCHEMA ext


-- ADF - Azure Data Factory
-- Hent zip fil fra SSI: https://files.ssi.dk/covid19/overvagning/data/overvaagningsdata-covid19-20042022-p2vl
-- -- put csv filer i vores datalake

-- Linked services
-- t�nk det som endpoints/connectionstring - dvs credentials og adressen

-- 2 dataset
-- 

-- 

CREATE LOGIN loginnavn WITH Password='Pa55w.rd1234'









