# Databricks notebook source
print('Hello from databricks!')

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.userInfoFunctions.enabled = true;
# MAGIC select current_user()