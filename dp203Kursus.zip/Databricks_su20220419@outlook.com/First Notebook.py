# Databricks notebook source
navn='Mette'
print(navn)

# COMMAND ----------

# ipynb er default filformat for notebooks



# COMMAND ----------

# MAGIC %fs
# MAGIC ls

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/FileStore/raspdatauploaded/

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/FileStore/raspdatauploaded/data2022_04_19_11_19_06.csv