--Microsoft SQL Azure (RTM) - 12.0.2000.8   Mar 31 2022 08:13:33   Copyright (C) 2021 Microsoft Corporation 
SELECT @@version

-- 11 er synapse serverless her
SELECT serverproperty('engineedition')

SELECT SUSER_NAME()

-- m� jeg som sql admin l�se fra view?
SELECT		*
FROM		dbo.vRaspData

-- dem som har adgang til dette credential kan nu l�se data fra vores view...
CREATE CREDENTIAL [https://datalakesu20220419.dfs.core.windows.net/raspberry]
WITH IDENTITY='Managed Identity'

-- kr�ver en bruger fra AD til at g�re dette...
CREATE LOGIN [BI Group] FROM EXTERNAL PROVIDER

SELECT		*
FROM		sys.server_principals


CREATE USER LoaderRC20 FOR LOGIN LoaderRC20;
