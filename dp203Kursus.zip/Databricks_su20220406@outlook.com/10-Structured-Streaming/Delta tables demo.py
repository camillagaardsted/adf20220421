# Databricks notebook source
# MAGIC %fs
# MAGIC rm superusersdata

# COMMAND ----------

foldername="superusersdata"
filename="animals.csv"
dbutils.fs.mkdirs(foldername)
filepath=foldername+"/"+filename
data="Id,Navn\n1,Hest\n2,Kat\n3,Hund"
dbutils.fs.put(filepath,data,True)

# COMMAND ----------

print(dbutils.fs.head(filepath))

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE animalsTable

# COMMAND ----------

# File location and type
file_location = "/superusersdata/animals.csv"
file_type = "csv"

# CSV options
infer_schema = "true"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

permanent_table_name = "animalsTable"

#df.write.format("parquet").saveAsTable(permanent_table_name)
df.write.format("delta").saveAsTable(permanent_table_name)
# default format er delta nu i den spark version vi kører her
#df.write.saveAsTable(permanent_table_name)


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM animalsTable

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO animalsTable
# MAGIC VALUES(4,'Giraf')

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM animalsTable
# MAGIC WHERE Id=4

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE animalsTable
# MAGIC SET Navn='Flodhest'
# MAGIC WHERE Id=1

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE EXTENDED animalsTable

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/user/hive/warehouse/animalstable

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE animalsTable

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE history animalsTable

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM animalsTable

# COMMAND ----------

# MAGIC %sql
# MAGIC --https://docs.databricks.com/spark/latest/spark-sql/language-manual/delta-restore.html
# MAGIC RESTORE TABLE animalsTable TO VERSION AS OF 1

# COMMAND ----------

# MAGIC %fs ls dbfs:/superusersdata/

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS animals;
# MAGIC 
# MAGIC CREATE TABLE animals
# MAGIC USING csv
# MAGIC OPTIONS (path "dbfs:/superusersdata/*.csv", header "true")

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE EXTENDED animals

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM   animals

# COMMAND ----------

foldername="superusersdata"
filename="animals2.csv"
dbutils.fs.mkdirs(foldername)
filepath=foldername+"/"+filename
data="Id,Navn\n5,Flodhest\n6,Tiger\n7,And"
dbutils.fs.put(filepath,data,True)

# COMMAND ----------

# MAGIC %sql
# MAGIC REfRESH TABLE animals

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*) AS Antal
# MAGIC FROM   animals