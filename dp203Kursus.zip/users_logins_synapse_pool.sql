
-- st� p� master
CREATE LOGIN loginnavn WITH Password='Pa55w.rd1234'

CREATE USER loginnavn FOR LOGIN loginnavn

-- og i pool databasen
CREATE USER loginnavn FOR LOGIN loginnavn
EXEC sp_addrolemember 'db_owner', 'loginnavn';



https://files.ssi.dk/covid19/overvagning/data/overvaagningsdata-covid19-21042022-ooa4


-- stream analytics jobs

-- https://docs.microsoft.com/en-us/stream-analytics-query/tumbling-window-azure-stream-analytics









