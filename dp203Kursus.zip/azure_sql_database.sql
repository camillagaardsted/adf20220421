--Microsoft SQL Azure (RTM) - 12.0.2000.8   Feb 23 2022 11:32:53   Copyright (C) 2021 Microsoft Corporation 
SELECT @@version

--USE statement is not supported to switch between databases
USE master

SELECT @@SPID

-- external tables er spritnyt til Azure SQL Database

SELECT		*
FROM		sys.firewall_rules


