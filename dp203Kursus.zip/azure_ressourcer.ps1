﻿# PowerShell er et scripting sprog som findes i Windows - men blev cross platform for nogle år siden

# for at arbejde med Azure har vi på forhånd installeret modulet az
Install-Module az

# Vi har en template fra Azure portalen til at oprette en storage account med fileshare
# Template kaldes for en ARM template (Azure Resource Manager)

# se https://docs.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-powershell

$resourceGroup='dk'

Connect-AzAccount

Get-AzResourceGroup

# implicit oprettelse af ressourcer via ARM
New-AzResourceGroupDeployment -ResourceGroupName $resourceGroup  -TemplateFile C:\DP203Kursus\fileshare_storageaccount\template.json -TemplateParameterFile C:\DP203Kursus\fileshare_storageaccount\parameters.json

Get-AzStorageAccount


# opsætning af mit filehare her lokalt:

$connectTestResult = Test-NetConnection -ComputerName storageacc20220419.file.core.windows.net -Port 445


if ($connectTestResult.TcpTestSucceeded) {
    # Save the password so the drive will persist on reboot
    cmd.exe /C "cmdkey /add:`"storageacc20220419.file.core.windows.net`" /user:`"localhost\storageacc20220419`" /pass:`"SCb+5vrL/qGrzkw123FCAr4/DZGIAa/NzzeTlM4PE02JOOS1j3kwqXh8BzcqKOdbChZC7KwjZOFRszMnuEkmzA==`""
    # Mount the drive
    New-PSDrive -Name T -PSProvider FileSystem -Root "\\storageacc20220419.file.core.windows.net\marketing" -Persist
} else {
    Write-Error -Message "Unable to reach the Azure storage account via port 445. Check to make sure your organization or ISP is not blocking port 445, or use Azure P2S VPN, Azure S2S VPN, or Express Route to tunnel SMB traffic over a different port."
}


# Eksplicit oprettelse af ressourcer via Azure cmdlets:

#New-AzStorageAccount -ResourceGroupName $resourceGroup -Name
$ressourceGroup='dk'
$location='westeurope'
$dato = Get-Date -Format "yyyyMMdd"


$storageAccountName="storageaccountsu$dato"
New-AzStorageAccount -Name $storageAccountName -SkuName Standard_LRS -ResourceGroupName $ressourceGroup -Location $location -Kind StorageV2 -AccessTier Cool


$DataLakeName="datalakesu$dato"
New-AzStorageAccount -Name $DataLakeName -SkuName Standard_LRS -ResourceGroupName $ressourceGroup -Location $location -Kind StorageV2 -AccessTier Cool -EnableHierarchicalNamespace $true

# upload some data 
$storageAccount=Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $ressourceGroup

$blobcontainerName='blobcontainer'
New-AzStorageContainer -Name $blobcontainerName -Context $storageAccount.Context -Permission Container

# upload some files
$folder="C:\DP203Kursus\data\images"
Set-Location $folder

$year=(Get-Date).Year
$month=Get-date -Format "MMMM"

Set-AzStorageBlobContent -File .\mtb.jpg -Container $blobcontainerName -BlobType Block -Context $storageAccount.Context -blob "images\products\$year\$month\mtb.jpg"
Set-AzStorageBlobContent -File .\forgaffel.jpg -Container $blobcontainerName -BlobType Block -Context $storageAccount.Context -StandardBlobTier hot -Blob "images\products\$year\$month\forgaffel.jpg"


# upload some data 
$storageAccount=Get-AzStorageAccount -Name $DataLakeName -ResourceGroupName $ressourceGroup

$datalakecontainerName='datalakecontainer'
New-AzStorageContainer -Name $datalakecontainerName -Context $storageAccount.Context -Permission Container

# upload some files
$folder="C:\DP203Kursus\data\aidata"
Set-Location $folder

$year=(Get-Date).Year
$month=Get-date -Format "MMMM"

$files= dir -File
foreach ($file in $files){
    $fileName=$file.Name
    Set-AzStorageBlobContent -File $fileName -Container $datalakecontainerName -BlobType Block -Context $storageAccount.Context -blob "aidata\information\$year\$month\$fileName"
}


# list blobcontainer content
$storageAccount=Get-AzStorageAccount -Name $storageAccountName -ResourceGroupName $ressourceGroup
Get-AzStorageBlob -Container $blobcontainerName -Context $storageAccount.Context | select name





# list datalake container content

$storageAccount=Get-AzStorageAccount -Name $DataLakeName -ResourceGroupName $ressourceGroup
Get-AzStorageBlob -Container $datalakecontainerName -Context $storageAccount.Context |select name


# vi kan anvende Azure Storage Explorer til at se filer i datalake/blob
# https://azure.microsoft.com/en-us/features/storage-explorer/

# rasp
$datalakecontainerName='raspberry'
Get-AzStorageBlob -Container $datalakecontainerName -Context $storageAccount.Context |where name -like *csv | measure

# lav en fil som indholder noget ulovligt data  der giver problemer at tolke
# det kan være forkert antal af kolonner eller ulovlig type

$folder=Get-AzStorageBlob -Container $datalakecontainerName -Context $storageAccount.Context |where name -like *csv | select -last 1 -ExpandProperty name | Split-Path -Parent

$headerRow='sensorid,timestamp,temperature_from_humidity,temperature_from_pressure,humidity,pressure'
$dataRow='1984,2022-13-13T12:21:21,46.38788604736328,44.079166412353516,19.143821716308594,962.252685546875'
$fileName='data_corrupt_date.csv'
$headerRow | out-file $fileName -Encoding ascii
$dataRow | Out-File $fileName -Append 


Set-AzStorageBlobContent -File $fileName -Container $datalakecontainerName -BlobType Block -Context $storageAccount.Context -blob "$folder/$fileName"

# vi kan anvende azCLI lokalt eller i shell.azure.com

# https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli


# Databricks
#https://spark.apache.org/docs/latest/

# https://spark.apache.org/docs/latest/api/python/index.html

# Adgang til Azure storage account container via SAS (shared access signature)


# vi skal have nogle brugere i Azure

$pn=Get-AzDomain | select -ExpandProperty domains


$password="Pa55w.rd"
$passwordSecure=ConvertTo-SecureString -AsPlainText $password -Force

$username="otto"
$Name="Otto Pilfinger"
$upn = "$username@$pn"
$mailnickname="ottoregnskab"
$otto=New-AzADUser -DisplayName $Name -UserPrincipalName $upn -Password $passwordSecure -MailNickname $mailnickname

$username="ottoline"
$Name="Ottoline Pilfinger"
$upn = "$username@$pn"
$mailnickname="ottolinemarketing"
$ottoline=New-AzADUser -DisplayName $Name -UserPrincipalName $upn -Password $passwordSecure -MailNickname $mailnickname



$groupName="BI group"
$mailnickname="bigruppen"
$bigroup=New-AzADGroup -DisplayName $groupName -MailNickname $mailnickname 

Add-AzADGroupMember -TargetGroupDisplayName $groupName -MemberUserPrincipalName $otto.UserPrincipalName,$ottoline.UserPrincipalName

# IT folk:

$username="ivan"
$Name="Ivan IT"
$upn = "$username@$pn"
$mailnickname="ivanit"
$ivan=New-AzADUser -DisplayName $Name -UserPrincipalName $upn -Password $passwordSecure -MailNickname $mailnickname

$username="frode"
$Name="Frode Pilfinger"
$upn = "$username@$pn"
$mailnickname="frodeit"
$frode=New-AzADUser -DisplayName $Name -UserPrincipalName $upn -Password $passwordSecure -MailNickname $mailnickname

# Opret sikkerhedsgruppe til vores to IT folk
$groupName="IT group"
$mailnickname="itgruppen"
$bigroup=New-AzADGroup -DisplayName $groupName -MailNickname $mailnickname 

Add-AzADGroupMember -TargetGroupDisplayName $groupName -MemberUserPrincipalName $ivan.UserPrincipalName,$frode.UserPrincipalName


$otto.UserPrincipalName | clip


#############################################################
# DAg 2 - Synapse Analytics

#############################################################

# vi starter lige med at se en klassisk Azure SQL Database
$location='eastus'
$sqlServerName = 'sqlservercg20220420'
$cred=get-credential -UserName sqladmin -Message "indtast password"
New-AzSqlServer -ServerName $sqlServerName -ResourceGroupName $resourceGroup -Location $location -SqlAdministratorCredentials $cred

$databaseName='AdvCloud'
New-AzSqlDatabase -DatabaseName $databaseName -ServerName $sqlServerName -Edition Basic -SampleName AdventureWorksLT -ResourceGroupName $resourceGroup

mkdir C:\dp-203\synapsescripts
Export-AzSynapseSqlScript -WorkspaceName synapse20220420 -OutputFolder C:\dp-203\synapsescripts



